import { Link } from 'react-router-dom';

export default function Menu() {
  return (
    <nav style={{ padding: '15px', borderBottom: '2px solid #5c4b8b', textAlign: 'center', fontSize: '18px' }}>
      <strong>Komponent: Menu</strong><br /><br />
      <Link to="/" style={{ textDecoration: 'none', color: '#000' }}>Start (Intro)</Link> |{' '}
      <Link to="/sets" style={{ textDecoration: 'none', color: '#000' }}>Zestawy (sets)</Link> |{' '}
      <Link to="/parts" style={{ textDecoration: 'none', color: '#000' }}>Części (parts)</Link> |{' '}
      <Link to="/help" style={{ textDecoration: 'none', color: '#000' }}>Pomoc (help)</Link>
    </nav>
  );
}