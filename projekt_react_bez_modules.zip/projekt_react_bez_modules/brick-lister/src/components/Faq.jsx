import { useState } from 'react';

const pytania = [
    { id: 1, pyt: 'Jak zamówić klocki?', odp: 'Przejdź do zakładki Zestawy, wybierz zestaw i przejdź do Listy Części.' },
    { id: 2, pyt: 'Jak wygenerować PDF?', odp: 'Funkcja generowania PDF jest obecnie w fazie testów i została wyłączona.' },
    { id: 3, pyt: 'Gdzie znajdę instrukcje?', odp: 'Instrukcje w formacie PDF znajdują się pod odpowiednimi zestawami na liście.' }
];

export default function Faq() {
    const [aktywnePytanie, setAktywnePytanie] = useState(null);

    return (
        <div>
            <h3>Tematy pomocy (FAQ):</h3>
            <ul style={{ listStyleType: 'none', padding: 0 }}>
                {pytania.map((item) => (
                    <li key={item.id} style={{ marginBottom: '10px' }}>
                        <button
                            onClick={() => setAktywnePytanie(item.id)}
                            style={{ width: '100%', textAlign: 'left', padding: '8px', cursor: 'pointer', background: '#f4f4f4', border: '1px solid #ccc' }}
                        >
                            {item.id}. {item.pyt}
                        </button>
                        {/* Wyświetlanie odpowiedzi tylko dla klikniętego pytania */}
                        {aktywnePytanie === item.id && (
                            <div style={{ padding: '10px', backgroundColor: '#e6ffe6', border: '1px solid #99ff99', marginTop: '5px' }}>
                                <strong>Odpowiedź:</strong> {item.odp}
                            </div>
                        )}
                    </li>
                ))}
            </ul>
        </div>
    );
}