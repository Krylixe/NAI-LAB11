import { useState } from 'react';

export default function Form() {
    const [autor, setAutor] = useState('');
    const [tytul, setTytul] = useState('');
    const [tresc, setTresc] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault(); // Zapobiega przeładowaniu strony
        console.log("--- WYSŁANO FORMULARZ ---");
        console.log("Autor:", autor);
        console.log("Tytuł:", tytul);
        console.log("Treść:", tresc);
        alert("Wiadomość została wysłana! Sprawdź konsolę (F12).");
    };

    return (
        <div>
            <h3>Wyślij e-mail do autora:</h3>
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <label>
                    Autor: <input type="text" value={autor} onChange={(e) => setAutor(e.target.value)} required style={{ width: '100%' }} />
                </label>
                <label>
                    Tytuł: <input type="text" value={tytul} onChange={(e) => setTytul(e.target.value)} required style={{ width: '100%' }} />
                </label>
                <label>
                    Treść: <textarea value={tresc} onChange={(e) => setTresc(e.target.value)} required style={{ width: '100%', height: '80px' }} />
                </label>
                <button type="submit" style={{ padding: '10px', backgroundColor: '#5c4b8b', color: 'white', border: 'none', cursor: 'pointer' }}>
                    (Wyślij)
                </button>
            </form>
        </div>
    );
}