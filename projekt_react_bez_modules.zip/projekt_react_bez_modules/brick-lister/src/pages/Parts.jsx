import { useSearchParams } from 'react-router-dom';
import RegularList from '../layouts/RegularList';
import ListItem from '../layouts/ListItem';

export default function Parts() {
    // Odczytanie identyfikatora zestawu z adresu URL (np. ?set=6277)
    const [searchParams] = useSearchParams();
    const setId = searchParams.get('set') || 'Nie wybrano';

    // Wpisane "na sztywno" dane z powodu wykreślenia odczytu plików CSV
    const czesci = [
        { id: 1, nazwa: 'Brick 2x4', numer: '3001', cena: 0.50, obraz: 'https://via.placeholder.com/50' },
        { id: 2, nazwa: 'Plate 1x2', numer: '3023', cena: 0.15, obraz: 'https://via.placeholder.com/50' },
        { id: 3, nazwa: 'Tile 1x1', numer: '3070', cena: 0.10, obraz: 'https://via.placeholder.com/50' },
    ];

    return (
        <div style={{ border: '2px solid #e0245e', padding: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                    <p style={{ margin: 0 }}>Strona: Lista</p>
                    <h3 style={{ margin: '5px 0 0 0', color: '#e0245e' }}>Zestaw: {setId}</h3>
                </div>
                <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column', gap: '5px' }}>
                    {/* Przyciski są na makiecie, ale ich funkcje w instrukcji są wykreślone */}
                    <button disabled>Pobierz CSV</button>
                    <button disabled>Generuj PDF</button>
                </div>
            </div>

            <RegularList>
                {czesci.map(czesc => (
                    <ListItem
                        key={czesc.id}
                        obraz={czesc.obraz}
                        nazwa={czesc.nazwa}
                        numer={czesc.numer}
                        cena={czesc.cena}
                    />
                ))}
            </RegularList>
        </div>
    );
}