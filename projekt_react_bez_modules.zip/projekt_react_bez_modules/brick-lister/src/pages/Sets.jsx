import { Link } from 'react-router-dom';

const availableSets = [
    { id: '6263', image: '6263_preview.jpg', pdf: '6263_inst.pdf' },
    { id: '6265', image: '6265_preview.jpg', pdf: null },
    { id: '6266', image: '6266_preview.jpg', pdf: '6266_inst.pdf' },
    { id: '6267', image: '6267_preview.jpg', pdf: '6267_inst.pdf' },
    { id: '6277', image: '6277_preview.jpg', pdf: null }
];

export default function Sets() {
    return (
        <div>
            <h2 style={{ textAlign: 'center', marginBottom: '30px' }}>Podstrona: Zestawy (Sets)</h2>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center' }}>
                {availableSets.map((set) => (
                    <div key={set.id} style={{ border: '2px solid #5c4b8b', padding: '15px', width: '220px', textAlign: 'center', backgroundColor: '#f9f9f9' }}>
                        <h3 style={{ margin: '0 0 10px 0' }}>{set.id}</h3>

                        <img
                            src={`/media/${set.image}`}
                            alt={`Zestaw ${set.id}`}
                            style={{ width: '100%', height: '150px', objectFit: 'cover', border: '1px solid #ccc', marginBottom: '15px' }}
                            onError={(e) => { e.target.src = 'https://via.placeholder.com/150?text=Brak+zdjecia'; }}
                        />

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            <Link to={`/parts?set=${set.id}`} style={{ textDecoration: 'none', color: '#0056b3', fontWeight: 'bold' }}>
                                Lista części
                            </Link>

                            {set.pdf && (
                                <a href={`/media/${set.pdf}`} target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none', color: '#d9534f', fontWeight: 'bold' }}>
                                    Instrukcja
                                </a>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}