import { useState } from 'react';
import SplitScreen from '../layouts/SplitScreen';
import Faq from '../components/Faq';
import Form from '../components/Form';

export default function Help() {
    // Hook sterujący układem SplitScreen (pionowo / poziomo)
    const [isVertical, setIsVertical] = useState(false);

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <h2>Strona: Pomoc</h2>
                <button
                    onClick={() => setIsVertical(!isVertical)}
                    style={{ padding: '10px', cursor: 'pointer', backgroundColor: '#e0245e', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    (zmień układ na {isVertical ? 'Poziomy' : 'Pionowy'})
                </button>
            </div>

            {/* Wywołanie szablonu i wstrzyknięcie do niego komponentów */}
            <SplitScreen
                isVertical={isVertical}
                leftWeight={1}
                rightWeight={1}
                left={<Faq />}
                right={<Form />}
            />
        </div>
    );
}