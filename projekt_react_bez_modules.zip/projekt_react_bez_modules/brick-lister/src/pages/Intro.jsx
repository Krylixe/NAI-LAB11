export default function Intro() {
    return (
        <div>
            <h2>Strona Główna (Intro)</h2>
            <p>Witamy w aplikacji Brick Lister. Wybierz zakładkę z menu powyżej, aby rozpocząć.</p>
        </div>
    );
}