import { useState } from 'react';

export default function ListItem({ obraz, nazwa, numer, cena }) {
    // Hook useState do obsługi zmiany ilości klocków
    const [ilosc, setIlosc] = useState(1);

    // Dynamiczne przeliczanie wartości (ilość * cena)
    const wartosc = (ilosc * cena).toFixed(2);

    return (
        <tr>
            <td style={{ border: '1px solid #5c4b8b', padding: '10px', textAlign: 'center' }}>
                <img src={obraz} alt={nazwa} style={{ width: '50px' }} />
            </td>
            <td style={{ border: '1px solid #5c4b8b', padding: '10px' }}>
                <strong>{nazwa}</strong><br />
                <small>{numer}</small>
            </td>
            <td style={{ border: '1px solid #5c4b8b', padding: '10px', textAlign: 'center' }}>
                <button onClick={() => setIlosc(Math.max(0, ilosc - 1))}>-</button>
                <span style={{ margin: '0 10px' }}>[{ilosc}]</span>
                <button onClick={() => setIlosc(ilosc + 1)}>+</button>
            </td>
            <td style={{ border: '1px solid #5c4b8b', padding: '10px', textAlign: 'right' }}>
                {cena.toFixed(2)} PLN
            </td>
            <td style={{ border: '1px solid #5c4b8b', padding: '10px', textAlign: 'right', fontWeight: 'bold' }}>
                {wartosc} PLN
            </td>
        </tr>
    );
}