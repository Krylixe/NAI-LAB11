export default function SplitScreen({ left, right, isVertical, leftWeight = 1, rightWeight = 1 }) {
    return (
        <div style={{
            display: 'flex',
            flexDirection: isVertical ? 'column' : 'row',
            gap: '20px',
            border: '2px solid #5c4b8b',
            padding: '20px'
        }}>
            <div style={{ flex: isVertical ? 'none' : leftWeight, border: '1px solid #ccc', padding: '15px' }}>
                {left}
            </div>
            <div style={{ flex: isVertical ? 'none' : rightWeight, border: '1px solid #ccc', padding: '15px' }}>
                {right}
            </div>
        </div>
    );
}