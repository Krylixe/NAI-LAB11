export default function RegularList({ children }) {
    return (
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
            <thead>
                <tr style={{ backgroundColor: '#f4f4f4', borderBottom: '2px solid #5c4b8b', textAlign: 'left' }}>
                    <th style={{ padding: '10px', border: '1px solid #5c4b8b' }}>Obraz</th>
                    <th style={{ padding: '10px', border: '1px solid #5c4b8b' }}>Nazwa / Numer</th>
                    <th style={{ padding: '10px', border: '1px solid #5c4b8b' }}>Ilość</th>
                    <th style={{ padding: '10px', border: '1px solid #5c4b8b' }}>Cena</th>
                    <th style={{ padding: '10px', border: '1px solid #5c4b8b' }}>Wartość</th>
                </tr>
            </thead>
            <tbody>
                {children}
            </tbody>
        </table>
    );
}