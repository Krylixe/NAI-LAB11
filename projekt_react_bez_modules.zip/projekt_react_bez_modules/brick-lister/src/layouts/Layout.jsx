import { Outlet } from 'react-router-dom';
import Menu from '../components/Menu';

export default function Layout() {
    return (
        <div style={{ border: '3px solid #4a6fa5', margin: '20px', minHeight: '80vh' }}>
            <Menu />
            <div style={{ padding: '20px' }}>
                <Outlet />
            </div>
        </div>
    );
}